vim.g.python3_host_prog = '/usr/bin/python3'
require("options")
require("colorscheme")
require("keymaps")
require("plugins")
require("conf")
require("lsp")

vim.g.vsnip_snippet_dir = vim.fn.expand("~/.config/nvim/snippets")


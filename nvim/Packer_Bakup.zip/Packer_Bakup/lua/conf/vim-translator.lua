vim.cmd [[
  let g:translator_target_lang = 'zh'
  let g:translator_default_engines = ['google', 'bing']
]]


#!/usr/bin/env sh

make

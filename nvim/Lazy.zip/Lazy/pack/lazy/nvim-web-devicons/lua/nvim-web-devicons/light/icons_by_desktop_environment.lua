return { -- this file is generated from lua/nvim-web-devicons/default/icons_by_desktop_environment.lua, please do not edit
  ["budgie"]   = { icon = "", color = "#4E5361", cterm_color = "240", name = "Budgie"    },
  ["cinnamon"] = { icon = "", color = "#93451F", cterm_color = "124", name = "Cinnamon"  },
  ["gnome"]    = { icon = "", color = "#333333", cterm_color = "236", name = "GNOME"     },
  ["lxde"]     = { icon = "", color = "#525252", cterm_color = "239", name = "LXDE"      },
  ["lxqt"]     = { icon = "", color = "#016D9E", cterm_color = "24",  name = "LXQt"      },
  ["mate"]     = { icon = "", color = "#4E6D2E", cterm_color = "22",  name = "MATE"      },
  ["plasma"]   = { icon = "", color = "#1467B7", cterm_color = "25",  name = "KDEPlasma" },
  ["xfce"]     = { icon = "", color = "#0080A7", cterm_color = "31",  name = "Xfce"      },
} --[[@as table<string, Icon>]]

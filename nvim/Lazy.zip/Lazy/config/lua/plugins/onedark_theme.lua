local onedark_cfg = {
    --style = 'dark',
    --style = 'darker',
    --style = 'cool',
    --style = 'deep',
    --style = 'warm',
    style = 'warmer',
    transparent = true,
    -- lualine = {
    --     transparent = true
    -- },
}

return {
  "navarasu/onedark.nvim",
  priority = 1000, -- make sure to load this before all the other start plugins
  config = function()
    require('onedark').setup(onedark_cfg)
    -- Enable theme
    require('onedark').load()
  end
}
return {
    "lukas-reineke/indent-blankline.nvim",
    tag = "v3.9.0",
    lazy = false,
    config = function()
        require("ibl").setup({})
    end,
}

vim.g.mapleader = ';'
vim.g.maplocalleader = ';'

local keymap = vim.api.nvim_set_keymap
local opts = { noremap = true, silent = true }
keymap("", ";", "<Nop>", opts)

-- Insert --
keymap('i', 'jj', '<Esc>', opts)

-- Normal --
-- Better window natigation
keymap('n','<leader>q','<Cmd>q<CR>', opts)
keymap('n','<leader>w','<Cmd>w<CR>', opts)
keymap('n','<leader>x','<Cmd>wq<CR>', opts)

-- 分屏--
keymap("n", "s", "<Nop>", opts)
keymap("n", "<space>", "<Nop>", opts)
keymap("n", "sv", ":vsp<CR>", opts)
keymap("n", "sd", ":sp<CR>", opts)
keymap("n", "sc", "<C-w>c", opts)
keymap("n", "so", "<C-w>o", opts) -- close others
keymap("n", "<space>h", "<C-w>h", opts)
keymap("n", "<space>j", "<C-w>j", opts)
keymap("n", "<space>k", "<C-w>k", opts)
keymap("n", "<space>l", "<C-w>l", opts)
-- 比例控制（不常用，因为支持鼠标拖拽）
keymap("n", "s[", ":vertical resize +20<CR>", opts)
keymap("n", "s]", ":vertical resize -20<CR>", opts)
keymap("n", "s=", "<C-w>=", opts)
keymap("n", "<C-Up>", ":resize +10<CR>",opts)
keymap("n", "<C-Down>", ":resize -10<CR>",opts)
